package com.codingdojo.overflow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DojoOverFlowApplication {

	public static void main(String[] args) {
		SpringApplication.run(DojoOverFlowApplication.class, args);
	}
}
